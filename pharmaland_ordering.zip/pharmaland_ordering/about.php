<section class="py-5">
    <div class="container">
        <div class="card rounded-0">
            <div class="card-body">
                <?= htmlspecialchars_decode(file_get_contents('./about.html')) ?>
            </div>
        </div>
    </div>
</section>