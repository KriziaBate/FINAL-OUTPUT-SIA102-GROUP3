-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 27, 2023 at 09:56 AM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pharma_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart_list`
--

CREATE TABLE `cart_list` (
  `id` int(30) NOT NULL,
  `customer_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `category_list`
--

CREATE TABLE `category_list` (
  `id` int(30) NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `category_list`
--

INSERT INTO `category_list` (`id`, `name`, `description`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
(1, 'Tablet', 'SAMPLE ONLY', 1, 0, '2022-10-25 10:14:16', '2023-03-26 00:03:00'),
(2, 'Capsule', 'SAMPLE ONLY', 1, 0, '2022-10-25 10:14:16', '2023-03-26 00:03:11'),
(3, 'Syrup', 'SAMPLE ONLY', 1, 0, '2022-10-25 10:14:16', '2023-03-26 00:02:46'),
(5, 'Diaper', 'SAMPLE ONLY', 1, 0, '2022-10-25 10:14:16', '2023-03-26 00:05:11'),
(6, 'Milk', 'SAMPLE ONLY', 1, 0, '2022-10-25 10:14:16', '2023-03-26 00:05:21');

-- --------------------------------------------------------

--
-- Table structure for table `customer_list`
--

CREATE TABLE `customer_list` (
  `id` int(30) NOT NULL,
  `firstname` text NOT NULL,
  `lastname` text NOT NULL,
  `province` varchar(100) NOT NULL,
  `municipality` varchar(100) NOT NULL,
  `barangay` varchar(100) NOT NULL,
  `street` text NOT NULL,
  `contact` text NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customer_list`
--

INSERT INTO `customer_list` (`id`, `firstname`, `lastname`, `province`, `municipality`, `barangay`, `street`, `contact`, `email`, `password`, `avatar`, `date_created`, `date_updated`) VALUES
(10, 'Jochelle', 'Rivera', 'Pampanga', 'Candaba', 'Bahay Pare', '006 Benigno Aquino Avenue', '09505716034', 'jocel@gmail.com', '202cb962ac59075b964b07152d234b70', 'uploads/customers/10.png?v=1679902314', '2023-03-27 15:31:54', '2023-03-27 15:31:54'),
(11, 'Russel ', 'Evangelista', 'Pampanga', 'Candaba', 'Bahay Pare', '123 Tabing Ilog', '09234562123', 'russel@gmail.com', '202cb962ac59075b964b07152d234b70', 'uploads/customers/11.png?v=1679902520', '2023-03-27 15:35:20', '2023-03-27 15:35:20');

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `order_id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL DEFAULT 0,
  `price` float(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`order_id`, `product_id`, `quantity`, `price`) VALUES
(10, 5, 3, 375.00),
(11, 4, 5, 1500.00),
(12, 3, 1, 500.00),
(13, 1, 5, 200.00);

-- --------------------------------------------------------

--
-- Table structure for table `order_list`
--

CREATE TABLE `order_list` (
  `id` int(30) NOT NULL,
  `code` varchar(100) NOT NULL,
  `customer_id` int(30) NOT NULL,
  `message` text NOT NULL,
  `total_amount` float(12,2) NOT NULL DEFAULT 0.00,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=pending,\r\n1=packed,\r\n2=out for delivery,\r\n3=paid\r\n',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_list`
--

INSERT INTO `order_list` (`id`, `code`, `customer_id`, `message`, `total_amount`, `status`, `date_created`, `date_updated`) VALUES
(10, '2023032700001', 10, 'Keep Fighting!', 1125.00, 0, '2023-03-27 15:32:32', '2023-03-27 15:32:32'),
(11, '2023032700002', 11, 'Thank You Lord!', 7500.00, 2, '2023-03-27 15:35:54', '2023-03-27 15:36:21'),
(12, '2023032700003', 10, 'Think Positive!', 500.00, 0, '2023-03-27 15:40:42', '2023-03-27 15:40:42'),
(13, '2023032700004', 11, 'Worth It!', 1000.00, 0, '2023-03-27 15:41:51', '2023-03-27 15:41:51');

-- --------------------------------------------------------

--
-- Table structure for table `product_list`
--

CREATE TABLE `product_list` (
  `id` int(30) NOT NULL,
  `category_id` int(30) NOT NULL,
  `brand` text NOT NULL,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `dose` varchar(250) NOT NULL,
  `price` float(12,2) NOT NULL DEFAULT 0.00,
  `image_path` text DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `delete_flag` tinyint(1) NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product_list`
--

INSERT INTO `product_list` (`id`, `category_id`, `brand`, `name`, `description`, `dose`, `price`, `image_path`, `status`, `delete_flag`, `date_created`, `date_updated`) VALUES
(1, 1, 'Brand 101', 'Mefenamic', 'SAMPLE ONLY', '500mg', 200.00, 'uploads/medicines//Mefenamic-acid-Ritemed-500-mg.jpg?v=1679760647', 1, 0, '2022-11-14 11:06:29', '2023-03-23 10:47:00'),
(2, 2, 'Brand 101', 'Amoxicillin', 'SAMPLE ONLY', '250', 180.00, 'uploads/medicines//download.jpg?v=1679760548', 1, 0, '2022-11-14 11:10:23', '2023-03-26 00:33:26'),
(3, 5, 'Brand 102', 'Pampers ', 'SAMPLE ONLY', 'Large', 500.00, 'uploads/medicines//Pampers-Baby-Dry-Diaper-Large-30s-500x500-product_popup.png?v=1679760748', 1, 0, '2022-11-14 11:11:36', '2023-03-26 00:33:42'),
(4, 6, 'Brand 103', 'Enfagrow', 'SAMPLE ONLY', '1.8kg', 1500.00, 'uploads/medicines//214new.jpg?v=1679761084', 1, 0, '2022-11-14 14:18:48', '2023-03-26 00:33:59'),
(5, 5, 'Brand 103', 'EQ', 'SAMPLE ONLY', 'Small', 375.00, 'uploads/medicines//EQ-Plus-Baby-Diaper-Small-12s-Plus-1s-500x500-product_popup.jpg?v=1679760852', 1, 0, '2022-11-14 10:59:44', '2023-03-26 00:34:14'),
(7, 6, 'Brand 104', 'Nido', 'SAMPLE ONLY', '2.2kg', 1600.00, 'uploads/medicines//Nido-baby-milk-powder.jpg?v=1679761201', 1, 0, '2022-11-14 00:20:01', '2023-03-26 00:34:42'),
(8, 2, 'Brand 104', 'Medicol', 'SAMPLE ONLY', '400mg', 200.00, 'uploads/medicines//medicol-advance-400-product-shot.jpg?v=1679761284', 1, 0, '2022-11-14 00:21:24', '2023-03-26 00:35:04'),
(9, 2, 'Brand 105', 'Loperamide', 'SAMPLE ONLY', '2mg', 300.00, 'uploads/medicines//images.jpg?v=1679761391', 1, 0, '2022-11-14 00:23:11', '2023-03-26 00:35:27');

-- --------------------------------------------------------

--
-- Table structure for table `stock_list`
--

CREATE TABLE `stock_list` (
  `id` int(30) NOT NULL,
  `product_id` int(30) NOT NULL,
  `code` varchar(100) NOT NULL,
  `quantity` float(12,2) NOT NULL DEFAULT 0.00,
  `expiration` date DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `stock_list`
--

INSERT INTO `stock_list` (`id`, `product_id`, `code`, `quantity`, `expiration`, `date_created`, `date_updated`) VALUES
(1, 2, '1236548', 50.00, '2022-05-27', '2022-05-25 11:48:05', '2022-05-25 11:48:05'),
(2, 2, '8754665', 15.00, '2023-05-25', '2022-05-25 11:54:40', '2022-05-25 11:58:07'),
(3, 2, '111', 35.00, '2022-05-24', '2022-05-25 11:58:24', '2022-05-25 11:58:24'),
(4, 1, '1231', 35.00, '2023-05-26', '2022-05-25 12:06:04', '2022-05-25 12:06:04'),
(5, 3, '123111', 50.00, '2023-05-26', '2022-05-25 12:06:19', '2022-05-25 12:06:19'),
(6, 4, '89756452', 30.00, '2025-06-23', '2022-05-25 14:19:25', '2022-05-25 14:19:25'),
(7, 5, '06231415', 50.00, '2023-05-27', '2022-05-26 11:01:03', '2022-05-26 11:01:03'),
(8, 5, '9875652', 15.00, '2022-05-09', '2022-05-26 11:01:21', '2022-05-26 11:01:41'),
(10, 8, '1222', 5.00, '2027-04-28', '2023-03-26 00:36:36', '2023-03-26 00:36:36'),
(11, 7, 'eee', 1.00, '2025-07-26', '2023-03-26 00:37:34', '2023-03-26 00:37:34'),
(12, 2, '11111111', 10.00, '2027-02-27', '2023-03-27 15:50:35', '2023-03-27 15:50:35');

-- --------------------------------------------------------

--
-- Table structure for table `stock_out`
--

CREATE TABLE `stock_out` (
  `id` int(30) NOT NULL,
  `order_id` int(30) NOT NULL,
  `stock_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `system_info`
--

CREATE TABLE `system_info` (
  `id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'Pharmaland Drugstore'),
(6, 'short_name', 'Pharmaland Drugstore'),
(11, 'logo', 'uploads/logs.png'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/cover.png?v=1653443581'),
(17, 'phone', '456-987-1231'),
(18, 'mobile', '09123456987 / 094563212222 '),
(19, 'email', 'pharmaland88@gmail.com'),
(20, 'address', 'Bahay Pare Candaba, Pampanga');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(50) NOT NULL,
  `firstname` varchar(250) NOT NULL,
  `middlename` text DEFAULT NULL,
  `lastname` varchar(250) NOT NULL,
  `mobile_number` varchar(20) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci COMMENT='2';

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `firstname`, `middlename`, `lastname`, `mobile_number`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(1, 'Pharmaland', '', 'Admin', '', 'admin', '0192023a7bbd73250516f069df18b500', 'uploads/logs.png', NULL, 1, '2021-01-20 14:02:37', '2023-03-24 22:22:41'),
(8, 'Russel', 'Cano', 'Evangelista', '', 'russel', '202cb962ac59075b964b07152d234b70', 'uploads/avatars/8.png?v=1679667112', NULL, 2, '2023-03-24 22:11:52', '2023-03-24 22:12:03'),
(9, 'Jhon', 'Areel', 'Locton', '09239345418', 'areel', '202cb962ac59075b964b07152d234b70', 'uploads/avatars/9.png?v=1679667154', NULL, 3, '2023-03-24 22:12:34', '2023-03-27 15:33:58');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart_list`
--
ALTER TABLE `cart_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `category_list`
--
ALTER TABLE `category_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customer_list`
--
ALTER TABLE `customer_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `order_list`
--
ALTER TABLE `order_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `customer_id` (`customer_id`);

--
-- Indexes for table `product_list`
--
ALTER TABLE `product_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `category_id` (`category_id`);

--
-- Indexes for table `stock_list`
--
ALTER TABLE `stock_list`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `stock_out`
--
ALTER TABLE `stock_out`
  ADD PRIMARY KEY (`id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `stock_id` (`stock_id`);

--
-- Indexes for table `system_info`
--
ALTER TABLE `system_info`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart_list`
--
ALTER TABLE `cart_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `category_list`
--
ALTER TABLE `category_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `customer_list`
--
ALTER TABLE `customer_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `order_list`
--
ALTER TABLE `order_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `product_list`
--
ALTER TABLE `product_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `stock_list`
--
ALTER TABLE `stock_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `stock_out`
--
ALTER TABLE `stock_out`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `system_info`
--
ALTER TABLE `system_info`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `cart_list`
--
ALTER TABLE `cart_list`
  ADD CONSTRAINT `customer_id_fk_cl` FOREIGN KEY (`customer_id`) REFERENCES `customer_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `product_id_fk_cl` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_id_fk_oi` FOREIGN KEY (`order_id`) REFERENCES `order_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `product_id_fk_oi` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `order_list`
--
ALTER TABLE `order_list`
  ADD CONSTRAINT `customer_id_fk_ol` FOREIGN KEY (`customer_id`) REFERENCES `customer_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `product_list`
--
ALTER TABLE `product_list`
  ADD CONSTRAINT `category_id_fk_pl` FOREIGN KEY (`category_id`) REFERENCES `category_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `stock_list`
--
ALTER TABLE `stock_list`
  ADD CONSTRAINT `product_id_fk_sl` FOREIGN KEY (`product_id`) REFERENCES `product_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;

--
-- Constraints for table `stock_out`
--
ALTER TABLE `stock_out`
  ADD CONSTRAINT `order_id_fk_so` FOREIGN KEY (`order_id`) REFERENCES `order_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `stock_id_fk_so` FOREIGN KEY (`stock_id`) REFERENCES `stock_list` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
